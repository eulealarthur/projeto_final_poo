package pedido;

import produtos.Produto;

public class PedidoItens {
    // Atributos da classe PedidoItens
    private Produto produto; // O produto associado ao item
    private int quantidade; // A quantidade do produto
    private double valorUnitario; // O valor unitário do produto
    private double valorDesconto; // O valor do desconto aplicado no produto
    private int idPedido; // O ID do pedido ao qual este item pertence

    // Construtor padrão
    public PedidoItens() {
    }

    // Construtor com argumentos
    public PedidoItens(Produto produto, int quantidade) {
        this.produto = produto;
        this.quantidade = quantidade;
        this.valorUnitario = produto.getValorVenda(); // Assume que o valor unitário é o valor de venda do produto
        this.valorDesconto = 0; // Inicialmente, o desconto é zero
    }

    // Getters e setters para acessar e modificar os atributos da classe
    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(double valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public double getValorDesconto() {
        return valorDesconto;
    }

    public void setValorDesconto(double valorDesconto) {
        this.valorDesconto = valorDesconto;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }
    
    // Método para obter o ID do produto associado ao item
    public int getIdProduto() {
        return produto.getIdProduto(); // Supondo que existe um método getIdProduto() na classe Produto
    }
    
    // Método para definir o ID do produto associado ao item
    public void setIdProduto(int idProduto) {
        produto.setIdProduto(idProduto); // Supondo que existe um método setIdProduto() na classe Produto
    }

    // Método para calcular o valor total do item no pedido
    public double calcularValorTotal() {
        return (valorUnitario * quantidade) - valorDesconto;
    }
    
    // Método para obter o valor total do item no pedido
    public double getValorTotal() {
        return (valorUnitario * quantidade) - valorDesconto;
    }
}