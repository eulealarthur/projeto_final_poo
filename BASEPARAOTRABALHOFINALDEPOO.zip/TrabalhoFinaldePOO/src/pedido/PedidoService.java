package pedido;

import java.util.Scanner;
import java.time.LocalDate;

import dao.PedidoDAO;
import dao.ClienteDAO;
import dao.ProdutoDAO;
import pessoas.Cliente;
import produtos.Produto;

public class PedidoService {
    private PedidoDAO pedidoDAO;
    private ProdutoDAO produtoDAO; 
    private Scanner scanner;

    public PedidoService() {
        this.pedidoDAO = new PedidoDAO();
        this.produtoDAO = new ProdutoDAO(); 
        this.scanner = new Scanner(System.in);
    }

    // Método para exibir o menu principal
    public void exibirMenuPrincipal() {
        int opcao;
        do {
            System.out.println("=== Menu Principal ===");
            System.out.println("1. Cadastrar Pedido");
            System.out.println("2. Alterar Pedido");
            System.out.println("3. Excluir Pedido");
            System.out.println("4. Imprimir Pedido com Cliente");
            System.out.println("5. Imprimir Pedido com Cliente e Produtos");
            System.out.println("6. Localizar Pedidos");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer do scanner

            switch (opcao) {
                case 1:
                    cadastrarPedido();
                    break;
                case 2:
                    alterarPedido();
                    break;
                case 3:
                    excluirPedido();
                    break;
                case 4:
                    imprimirPedidoComCliente();
                    break;
                case 5:
                    imprimirPedidoComClienteEProdutos();
                    break;
                case 6:
                    localizarPedidos();
                    break;
                case 0:
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (opcao != 0);
    }

    private void cadastrarPedido() {
        System.out.println("=== Cadastro de Pedido ===");
        
        // Solicita informações do pedido
        System.out.print("Digite a data de emissão (AAAA-MM-DD): ");
        LocalDate dataEmissao = LocalDate.parse(scanner.nextLine());
        System.out.print("Digite a data de entrega (AAAA-MM-DD): ");
        LocalDate dataEntrega = LocalDate.parse(scanner.nextLine());
        System.out.print("Digite a observação: ");
        String observacao = scanner.nextLine();
        
        // Solicita informações do cliente
        Cliente cliente = selecionarCliente();
        if (cliente == null) {
            System.out.println("Erro: Cliente inválido.");
            return;
        }
        
        // Cria o objeto Pedido
        Pedido pedido = new Pedido(dataEmissao, dataEntrega, observacao, cliente);
        
        // Adiciona produtos ao pedido
        boolean adicionarProduto = true;
        while (adicionarProduto) {
            Produto produto = selecionarProduto();
            if (produto == null) {
                System.out.println("Erro: Produto inválido.");
                continue; // Volta para o início do loop
            }
            
            System.out.print("Digite a quantidade: ");
            int quantidade = scanner.nextInt();
            scanner.nextLine(); // Limpa o buffer
            
            pedido.adicionarItem(produto, quantidade);
            
            System.out.print("Deseja adicionar outro produto? (S/N): ");
            String resposta = scanner.nextLine().toUpperCase();
            adicionarProduto = resposta.equals("S");
        }
        
        // Cadastra o pedido no banco de dados
        pedidoDAO.cadastrar(pedido);
        System.out.println("Pedido cadastrado com sucesso.");
    }
    
    private void alterarPedido() {
        System.out.println("=== Alteração de Pedido ===");
        System.out.print("Digite o ID do pedido que deseja alterar: ");
        int idPedido = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer
        
        Pedido pedido = pedidoDAO.buscarPorId(idPedido);
        if (pedido == null) {
            System.out.println("Pedido não encontrado.");
            return;
        }
        
        // Exibe informações do pedido antes da alteração
        System.out.println("Pedido atual:");
        System.out.println(pedido);
        
        // Opções de alteração de produtos
        System.out.println("Deseja alterar os produtos no pedido? (S/N)");
        String opcaoProdutos = scanner.nextLine().toUpperCase();
        if (opcaoProdutos.equals("S")) {
        	
            // Adicionar, remover ou alterar produtos
            // Lógica para adicionar um novo produto
            System.out.println("Deseja adicionar um novo produto? (S/N)");
            String adicionarNovo = scanner.nextLine().toUpperCase();
            if (adicionarNovo.equals("S")) {
                System.out.print("Digite o ID do produto que deseja adicionar: ");
                int idNovoProduto = scanner.nextInt();
                scanner.nextLine(); // Limpar o buffer
                Produto novoProduto = produtoDAO.buscarPorId(idNovoProduto);
                if (novoProduto == null) {
                    System.out.println("Produto não encontrado.");
                } else {
                    System.out.print("Digite a quantidade desejada: ");
                    int quantidade = scanner.nextInt();
                    scanner.nextLine(); // Limpar o buffer
                    pedido.adicionarItem(novoProduto, quantidade);
                }
            }
            
            // Lógica para remover um produto
            System.out.println("Deseja remover um produto? (S/N)");
            String removerProduto = scanner.nextLine().toUpperCase();
            if (removerProduto.equals("S")) {
                System.out.print("Digite o ID do produto que deseja remover: ");
                int idProdutoRemover = scanner.nextInt();
                scanner.nextLine(); // Limpar o buffer
                
                // Localiza o item do produto no pedido
                PedidoItens itemParaRemover = null;
                for (PedidoItens item : pedido.getItens()) {
                    if (item.getProduto().getId() == idProdutoRemover) {
                        itemParaRemover = item;
                        break;
                    }
                }
                
                // Verifica se o item foi encontrado e removê-lo do pedido
                if (itemParaRemover == null) {
                    System.out.println("Produto não encontrado no pedido.");
                } else {
                    pedido.removerItem(itemParaRemover);
                    System.out.println("Produto removido do pedido com sucesso.");
                }
            }
            
            // Lógica para alterar a quantidade de um produto
            System.out.println("Deseja alterar a quantidade de um produto? (S/N)");
            String alterarQuantidadeOpcao = scanner.nextLine().toUpperCase();
            if (alterarQuantidadeOpcao.equals("S")) {
                System.out.print("Digite o ID do produto que deseja alterar: ");
                int idProdutoAlterar = scanner.nextInt();
                scanner.nextLine(); // Limpar o buffer
                Produto produtoAlterar = produtoDAO.buscarPorId(idProdutoAlterar);
                if (produtoAlterar == null) {
                    System.out.println("Produto não encontrado.");
                } else {
                    // Localiza o item do produto no pedido
                    PedidoItens itemParaAlterar = null;
                    for (PedidoItens item : pedido.getItens()) {
                        if (item.getProduto().getId() == idProdutoAlterar) {
                            itemParaAlterar = item;
                            break;
                        }
                    }
                    if (itemParaAlterar == null) {
                        System.out.println("Produto não encontrado no pedido.");
                    } else {
                        System.out.print("Digite a nova quantidade: ");
                        int novaQuantidade = scanner.nextInt();
                        scanner.nextLine(); // Limpa o buffer
                        itemParaAlterar.setQuantidade(novaQuantidade);
                        System.out.println("Quantidade do produto alterada com sucesso.");
                    }
                }
            }
        }
        
        // Atualizar o pedido no banco de dados
        // pedidoDAO.atualizar(pedido); // Remova ou comente esta linha, pois o método atualizar não está definido
        System.out.println("Pedido alterado com sucesso.");
    }
    
    private void excluirPedido() {
        // tem que fazer a lógica pra excluir um pedido
    }

    private void imprimirPedidoComCliente() {
        // Tem que fazer a lógica para imprimir pedido com cliente
    }

    private void imprimirPedidoComClienteEProdutos() {
        // Tem que fazer a lógica para imprimir pedido com cliente e produtos
    }

    private void localizarPedidos() {
        // Tem que se fazer a lógica para localizar pedidos
    }

    // Método para selecionar um cliente
    private Cliente selecionarCliente() {
        System.out.print("Digite o ID do cliente: ");
        int idCliente = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer
        ClienteDAO clienteDAO = new ClienteDAO();
        return clienteDAO.buscarPorId(idCliente);
    }
    
    // Método para selecionar um produto
    private Produto selecionarProduto() {
        System.out.print("Digite o ID do produto: ");
        int idProduto = scanner.nextInt();
        scanner.nextLine(); // Limpa o buffer
        ProdutoDAO produtoDAO = new ProdutoDAO();
        return produtoDAO.buscarPorId(idProduto);
    }
}