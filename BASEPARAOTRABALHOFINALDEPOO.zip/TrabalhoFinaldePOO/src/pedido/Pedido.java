package pedido;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import produtos.Produto; 
import pessoas.Cliente; 

public class Pedido {
    private int idPedido;
    private LocalDate dataEmissao;
    private LocalDate dataEntrega;
    private String observacao;
    private Cliente cliente;
    private List<PedidoItens> itens;

    public Pedido(LocalDate dataEmissao, LocalDate dataEntrega, String observacao, Cliente cliente) {
        this.dataEmissao = dataEmissao;
        this.dataEntrega = dataEntrega;
        this.observacao = observacao;
        this.cliente = cliente;
        this.itens = new ArrayList<>();
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public LocalDate getDataEmissao() {
        return dataEmissao;
    }

    public void setDataEmissao(LocalDate dataEmissao) {
        this.dataEmissao = dataEmissao;
    }

    public LocalDate getDataEntrega() {
        return dataEntrega;
    }

    public void setDataEntrega(LocalDate dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public List<PedidoItens> getItens() {
        return itens;
    }

   
    public void adicionarItem(Produto produto, int quantidade) {
        PedidoItens item = new PedidoItens(produto, quantidade);
        this.itens.add(item);
    }

    public void removerItem(PedidoItens item) {
        this.itens.remove(item);
    }

    @Override
    public String toString() {
        return "Pedido [idPedido=" + idPedido + ", dataEmissao=" + dataEmissao + ", dataEntrega=" + dataEntrega
                + ", observacao=" + observacao + ", cliente=" + cliente + "]";
    }
}