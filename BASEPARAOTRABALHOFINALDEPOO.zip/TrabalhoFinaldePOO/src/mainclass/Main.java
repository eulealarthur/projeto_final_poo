package mainclass;

import pedido.PedidoService; // Importação da classe PedidoService

public class Main {
    public static void main(String[] args) {
        PedidoService pedidoService = new PedidoService(); // Instanciando o serviço de pedidos
        pedidoService.exibirMenuPrincipal(); // Exibindo o menu principal para o usuário interagir com o sistema
    }
}