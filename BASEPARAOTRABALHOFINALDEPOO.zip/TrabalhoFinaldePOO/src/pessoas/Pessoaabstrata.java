package pessoas;

import java.time.LocalDate;

public abstract class Pessoaabstrata {
    protected int idPessoa;
    protected String nome;
    protected String cpf;
    protected LocalDate dataNascimento;
    protected String endereco;
    protected String telefone;

    public Pessoaabstrata(String nome, String cpf, LocalDate dataNascimento) {
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
    }
}
