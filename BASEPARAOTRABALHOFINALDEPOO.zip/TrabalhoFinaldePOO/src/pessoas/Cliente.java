package pessoas;

import java.time.LocalDate;

public class Cliente extends Pessoaabstrata {
    private int idCliente;
    private String endereco;
    private String telefone;

    public Cliente(int idCliente, String nome, String cpf, LocalDate dataNascimento, String endereco, String telefone) {
        super(nome, cpf, dataNascimento);
        this.idCliente = idCliente;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    // Getters e setters para os atributos específicos do Cliente
    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }


    public String toString() {
        return "Cliente [idCliente=" + idCliente + ", nome=" + getNome() + ", cpf=" + getCpf() + ", dataNascimento=" + getdataNascimento()
                + ", endereco=" + endereco + ", telefone=" + telefone + "]";
    }

    // Método para obter o nome do cliente
    public String getNome() {
        return nome;
    }

    // Método para obter o CPF do cliente
    public String getCpf() {
        return cpf;
    }

    // Método para obter a data de nascimento do cliente
    public LocalDate getdataNascimento() {
        return dataNascimento;
    }
}