package dao;

import java.util.ArrayList;
import java.util.List;
import pedido.PedidoItens;

// Implementação concreta do DAO que não depende diretamente da conexão com o banco de dados
public class PedidoItensDAOImpl implements PedidoItensDAO {
    @Override
    public void cadastrar(PedidoItens item) {
        // Lógica para cadastrar no banco de dados
        System.out.println("Item cadastrado: " + item.toString());
    }

    @Override
    public List<PedidoItens> buscarPorIdPedido(int idPedido) {
        // Lógica para buscar no banco de dados
        System.out.println("Buscando itens do pedido com ID: " + idPedido);
        return new ArrayList<>();
    }

    @Override
    public void excluirPorPedido(int idPedido) {
        // Lógica para excluir no banco de dados
        System.out.println("Excluindo itens do pedido com ID: " + idPedido);
    }
}