package dao;

import java.util.List;
import pedido.PedidoItens;

// Interface para definir operações do DAO
public interface PedidoItensDAO {
    void cadastrar(PedidoItens item);
    List<PedidoItens> buscarPorIdPedido(int idPedido);
    void excluirPorPedido(int idPedido);
}
