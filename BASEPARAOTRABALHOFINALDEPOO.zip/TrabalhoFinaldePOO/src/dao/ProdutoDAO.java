package dao;

import java.util.HashMap;
import java.util.Map;

import produtos.Produto; // Importando a classe Produto

// Classe que simula o acesso aos dados dos produtos no banco de dados
public class ProdutoDAO {
    private Map<Integer, Produto> produtos; // Declaração de um mapa para armazenar os produtos por ID
    
    // Construtor da classe ProdutoDAO
    public ProdutoDAO() {
        this.produtos = new HashMap<>(); // Inicializa o mapa de produtos vazio
    }
    
    // Método para cadastrar um produto no banco de dados
    public void cadastrar(Produto produto) {
        // Simula a operação de cadastro de um produto no banco de dados, armazenando-o no mapa pelo ID
        produtos.put(produto.getIdProduto(), produto);
    }
    
    // Método para buscar um produto pelo seu ID no banco de dados
    public Produto buscarPorId(int id) {
        // Simula a operação de busca de um produto por ID no banco de dados, retornando o produto correspondente
        return produtos.get(id);
    }
}
