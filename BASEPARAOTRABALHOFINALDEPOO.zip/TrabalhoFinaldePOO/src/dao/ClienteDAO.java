package dao;

import java.util.HashMap;
import java.util.Map;

import pessoas.Cliente;

// Classe ClienteDAO para manipulação de objetos Cliente no banco de dados simulado
public class ClienteDAO {
    
    // Simula um banco de dados de clientes usando um mapa
    private Map<Integer, Cliente> clientes; 
    
    // Construtor da classe ClienteDAO
    public ClienteDAO() {
        // Inicializa o mapa de clientes como um novo HashMap
        this.clientes = new HashMap<>();
    }
    
    // Método para cadastrar um novo cliente no banco de dados
    public void cadastrar(Cliente cliente) {
        // Adiciona o cliente ao mapa usando seu ID como chave
        clientes.put(cliente.getIdCliente(), cliente);
    }
    
    // Método para buscar um cliente pelo seu ID no banco de dados
    public Cliente buscarPorId(int id) {
        // Retorna o cliente correspondente ao ID fornecido
        return clientes.get(id);
    }
}