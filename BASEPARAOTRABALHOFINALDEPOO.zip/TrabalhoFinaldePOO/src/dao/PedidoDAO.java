package dao;

import java.util.ArrayList;
import java.util.List;

import pedido.Pedido;

// Classe PedidoDAO para manipulação de objetos Pedido no banco de dados simulado
public class PedidoDAO {
    
    // Simula um banco de dados de pedidos usando uma lista
    private List<Pedido> pedidos;
    
    // Construtor da classe PedidoDAO
    public PedidoDAO() {
        // Inicializa a lista de pedidos como uma nova ArrayList
        this.pedidos = new ArrayList<>();
    }
    
    // Método para cadastrar um novo pedido no banco de dados
    public void cadastrar(Pedido pedido) {
        // Adiciona o pedido à lista de pedidos
        pedidos.add(pedido);
    }
    
    // Método para buscar um pedido pelo seu ID no banco de dados
    public Pedido buscarPorId(int id) {
        // Percorre a lista de pedidos procurando pelo ID correspondente
        for (Pedido pedido : pedidos) {
            if (pedido.getIdPedido() == id) {
                return pedido; // Retorna o pedido se encontrado
            }
        }
        return null; // Retorna null se o pedido não for encontrado
    }
    
    // Método para buscar todos os pedidos no banco de dados
    public List<Pedido> buscarTodos() {
        // Retorna a lista completa de pedidos
        return pedidos;
    }
    
    // Método para buscar todos os pedidos de um cliente pelo seu ID no banco de dados
    public List<Pedido> buscarPorCliente(int idCliente) {
        // Lista para armazenar os pedidos do cliente
        List<Pedido> pedidosCliente = new ArrayList<>();
        // Percorre a lista de pedidos
        for (Pedido pedido : pedidos) {
            // Verifica se o cliente do pedido tem o ID correspondente
            if (pedido.getCliente().getIdCliente() == idCliente) {
                pedidosCliente.add(pedido); // Adiciona o pedido à lista do cliente
            }
        }
        return pedidosCliente; // Retorna a lista de pedidos do cliente
    }
    
    // Método para excluir um pedido pelo seu ID no banco de dados
    public void excluir(int id) {
        // Busca o pedido pelo ID fornecido
        Pedido pedido = buscarPorId(id);
        if (pedido != null) {
            pedidos.remove(pedido); // Remove o pedido se encontrado
        }
    }
    
    // Método para atualizar um pedido no banco de dados
    public void atualizar(Pedido pedidoAtualizado) {
        // Percorre a lista de pedidos
        for (int i = 0; i < pedidos.size(); i++) {
            // Verifica se o pedido atual tem o mesmo ID do pedido a ser atualizado
            if (pedidos.get(i).getIdPedido() == pedidoAtualizado.getIdPedido()) {
                pedidos.set(i, pedidoAtualizado); // Atualiza o pedido na lista
                return;
            }
        }
    }
}