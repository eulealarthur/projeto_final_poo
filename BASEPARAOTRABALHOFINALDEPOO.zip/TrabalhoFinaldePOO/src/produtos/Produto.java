package produtos;

// Definição da classe Produto
public class Produto {
    private int idProduto; // Declaração do atributo idProduto
    private String descricao; // Declaração do atributo descricao
    private double valorCusto; // Declaração do atributo valorCusto
    private double valorVenda; // Declaração do atributo valorVenda
    private String categoria; // Declaração do atributo categoria

    // Construtor da classe Produto, que recebe diversos parâmetros para inicializar os atributos
    public Produto(int idProduto, String descricao, double valorCusto, double valorVenda, String categoria) {
        this.idProduto = idProduto;
        this.descricao = descricao;
        this.valorCusto = valorCusto;
        this.valorVenda = valorVenda;
        this.categoria = categoria;
    }

    // Getters e setters para os atributos da classe Produto
    public int getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValorCusto() {
        return valorCusto;
    }

    public void setValorCusto(double valorCusto) {
        this.valorCusto = valorCusto;
    }

    public double getValorVenda() {
        return valorVenda;
    }

    public void setValorVenda(double valorVenda) {
        this.valorVenda = valorVenda;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    // Método getId() para obter o ID do Produto
    public int getId() {
        return idProduto;
    }

    // Método toString para representação em string do Produto
    @Override
    public String toString() {
        return "Produto [idProduto=" + idProduto + ", descricao=" + descricao + ", valorCusto=" + valorCusto
                + ", valorVenda=" + valorVenda + ", categoria=" + categoria + "]";
    }
}