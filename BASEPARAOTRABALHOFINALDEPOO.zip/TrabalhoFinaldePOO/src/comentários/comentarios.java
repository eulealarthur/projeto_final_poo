package comentários;

public class comentarios {
	
	//aqui é a classe que eu usei apenas para organizar meus pensamentos e reunir as informações que consegui. 
	// espero que seja útil de alguma forma :)
	
// Coisas que faltam fazer:
	
		
	// - Integrar com o PostgresSQL
	
	// - Terminar as funçoes na classe do menu
	
	// - Verificar as classes DAO se estão sendo usadas da forma correta (tive dificuldade com elas e saber como usa-las então talvez elas precisem de modificação)
	
	// - Criar os Clientes no banco de dados (como foi pedido no enunciado)
	
// O que temos no código:
		
	
	//1 - Criação da Classe Main, inicializei os objetosDAO nela e criei instâncias de clientes, pedidos e produtos.
	// também botei para fazer operações como cadastro de clientes, adição de itens aos pedidos e busca de clientes e produtos.

   //2 - Criação da Classe Cliente (extensão da classe Pessoaabstrata) ela é feita para representar clientes no sisteminha (ID do cliente, nome, CPF, data de nascimento, endereço e telefone) 
	// e além disso, fiz alguns métodos para acessar e modificar essas informações.
	
   //3 - Criação da Classe Pedido, ela armazena informações do pedido (ID do pedido, data de emissão, data de entrega, valor total, observação e o cliente associado ao pedido)
	//ela tem uma lista de itens do pedido (classe PedidoItens). Possui métodos para adicionar itens ao pedido, calcular o valor total do pedido e para acessar e modificar as informações do pedido.
	
   //4 - Criação da classe Produto, ela representa um produto no sistema. e guarda ID do produto, descrição, valor de custo, valor de venda e categoria.
	//ela também tem métodos para acessar e mudar as informações.
	
   //5 - Criação da Classe PedidoItens que representa o item de um pedido, ai ela guarda informações como o produto associado ao item , o valor unitário e o valor de desconto
	
   //6 - Criação da Classe ClienteDAO que é responsável pela interação com a base de dados para operações relacionadas aos produtos, como cadastro e busca.
	
   //7 - Criação da Classe PedidoDAo é responsável pela interação com a base de dados para operações relacionadas aos pedidos, como cadastro e busca.

   //8 - Criação da classe ProdutoDAO que é responsável pela interação com a base de dados para operações relacionadas aos produtos, como cadastro e busca.
	
   //9 - Criação da Classe PedidoItensDAO é responsável pela interação com a base de dados para operações relacionadas aos itens de pedido (pedidoItens)
	//ela tem métodos para cadastrar itens de pedido no banco de dados e buscar itens de pedido por ID do pedido e possui métodos para cadastrar os detalhes do item e para buscar pelo id do pedido.
	
   //10 - Criação da Classe pessoa abstrata que tem os requisitos para ser a base da classe cliente.
	
   //11 - Criação da Classe ConexãoBanco que fornece métodos para obter e fechar conexões com o banco de dados PostgreSQL. (não finalizada)
	
  //12 - Fiz um menu bem bananinha só pra gente ter um início
	
	//ENUNCIADO DO TRABALHO
	
	//Construção do sistema:

	//	- Ter uma classe Pessoa abstrata. FEITO
	//	- Ter uma classe Cliente. FEITO
	//	- Ter uma classe Pedido. FEITO
	//	- Ter uma classe Produto. FEITO
	//	- Ter uma classe PedidoItens. FEITO
	//	- Ter uma interface CRUD. precisa fazer ainda em algumas!!
	//	- Ter classes DAO. FEITO MAS PRECISA DE UMA REVISÃO COM MAIOR CUIDADO
	//	- Ter um arquivo ini para conexão com a base de dados. ?
	//	- Conectar o sistema com o Postgres e fazer a persistência dos dados. ?
	
	//ANOTAÇÕES EXTRAS
	
	//@Override” é uma “annotation” que pode ser acrescentada a um método que foi sobreposto (“overridden”). 
	//Ela deve ser usada para métodos sobrepostos, não necessariamente aqueles que devem ser implementados devido ao uso de uma interface
}
