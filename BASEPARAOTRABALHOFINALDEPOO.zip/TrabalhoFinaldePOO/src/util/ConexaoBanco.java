package util;

public class ConexaoBanco {
//classe para ser colocada a integração com o postgres
}
